package matriculaInterface;

public interface IfazerMatricula {
	
	public void fazerMatricula();
		
		

}
